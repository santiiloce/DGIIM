#include <iostream>
#include <string>

int main(){
    std::string a = "Hola"; 
    std::string b = "Adios";
    std::cout << a + b << std::endl;
}