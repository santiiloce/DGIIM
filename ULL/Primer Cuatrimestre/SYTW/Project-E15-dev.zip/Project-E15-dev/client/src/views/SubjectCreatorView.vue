<script setup lang="ts">
import SubjectCreator from '@/components/SubjectCreator.vue'
import NavbarMenu from '@/components/NavbarMenu.vue'
</script>

<template>
    <header>
        <NavbarMenu />
    </header>
    <main>
        <SubjectCreator />
    </main>
</template>