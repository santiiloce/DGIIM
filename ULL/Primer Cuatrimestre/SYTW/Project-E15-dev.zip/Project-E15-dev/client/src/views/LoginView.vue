<script setup lang="ts">
import NavbarMenu from "@/components/NavbarMenu.vue"
import Userlogin from "@/components/Userlogin.vue";

</script>


<template>
<header>
  <NavbarMenu/>
</header>
  <main>
    <Userlogin/>
  </main>
</template>