<script setup lang="ts">
import MethodSelection from '@/components/MethodSelection.vue'
import NavbarMenu from '@/components/NavbarMenu.vue'
</script>   

<template>
    <main>
        <NavbarMenu />
        <MethodSelection />
    </main>
</template>
