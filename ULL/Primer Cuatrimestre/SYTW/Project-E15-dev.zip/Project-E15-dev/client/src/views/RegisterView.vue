<script setup lang="ts">
import NavbarMenu from "@/components/NavbarMenu.vue"
import RegisterUser from "@/components/Register_User.vue"
</script>

<template>
    <main>
        <div>
            <NavbarMenu />
            <RegisterUser />
        </div>
    </main>
</template>