/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Santiago Lopez Cerro alu0101763613@ull.edu.es
  * @date Nov 17 2024
  * @brief Altera las vocales de una cadena dada a mayuscula y las consonantes
  *        en minusculas
  * @bug Therea are  no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */
#include <iostream>
#include <cctype>
#include <string>

char TransformaLetra(char letra){
  char aux = std::tolower(letra);
  if (aux == 'a' || aux == 'e' || aux == 'i' || aux == 'o' || aux == 'u')
    aux = std::toupper(aux);
  return aux;
}

int main(int argc, char* argv[]){
    if (argc != 2){
      std::cerr << "Ejemplo de ejecucion: ./capitalize_vowels palabra ";
    return 1;
  }
  std::string palabra = argv[1];
  for (int i = 0; i < palabra.size(); i++){
    palabra[i] = TransformaLetra(palabra[i]);
  }
  std::cout << palabra << std::endl;
  return 0;
}
