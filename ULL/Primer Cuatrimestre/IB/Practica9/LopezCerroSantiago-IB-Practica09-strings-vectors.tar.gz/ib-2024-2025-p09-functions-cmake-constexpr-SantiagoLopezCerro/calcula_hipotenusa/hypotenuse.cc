/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Santiago Lopez Cerro alu0101763613@ull.edu.es
  * @date Nov 17 2024
  * @brief Dado los catetos de un triangulo calcula su hipotenusa
  * @bug Therea are  no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */
#include <iostream>

const double kEpsilon = 1e-4; 

double ApproximateRoot(double number){
  double root = 1.0;
  double delta = 1.0;
  while ( (abs( (root * root) - number) ) > kEpsilon){
    if (delta > 0){
      while ((root * root) < number){
        root += delta;
      }
    }
   else{
     while ((root * root ) > number){
       root += delta;
     }
   }
   delta *= -0.5;
  }
  return root;
}

double CalculateHypotenuse(double side1, double side2){
  return ApproximateRoot(side1 * side1 + side2 * side2);
}

int main(int argc, char* argv[]){
  if (argc != 3){
    std::cerr << "Ejemplo de ejecucion: ./hypotenuse 2 3 ";
    return 1;
  }
  double side1 = std::stoi(argv[1]);
  double side2 = std::stoi(argv[2]);
  if (side1 == 0 || side2 == 0){
    std::cerr << "Valores invalidos";
    return 1;
  }
  std::cout << CalculateHypotenuse(side1, side2) << std::endl;
  return 0;
}
