#include <iostream>
#include <string>

bool is_increasing(int n){
  std::string num2 = std::to_string(n);
  if(num2.size() == 2){
    int aux = n/10;
    int aux2 = n % 10;
    return (aux < aux2);
  }
  else{ 
    if( ((num2[0]) - '0') < (num2[1] - '0')){
      num2.erase(0,1);
      int aux = std::stoi(num2);
      is_increasing(aux);
    } 
    else
      return false;
  }
}

int main(){
  int n;   
  std::cin >> n;
  std::cout << is_increasing(n) << std::endl;
  return 0;
}
