#include <iostream>
#include <vector>

bool Matching(int size, std::vector<int> nums){
  bool odd = false;
  for(int i = 0; i < size; i++){
    for(int j = 0; j < size; j++){
      if (i == j)
        continue;
      if ((nums.at(i) + nums.at(j)) % 2 == 1)
        return true;
     }
  }
  return odd;
}

int main(){
  int size;
  while (std::cin >> size){
    std::vector<int> nums(size);
    for(int i = 0; i < size; i++)
      std::cin >> nums.at(i);
    if(Matching(size, nums))
      std::cout << "yes" << std::endl;
    else
      std::cout << "no" << std::endl;
  }
  return 0;
}   
    
  
