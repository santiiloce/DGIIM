/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Santiago Lopez Cerro alu0101763613@ull.edu.es
  * @date Nov 17 2024
  * @brief Calcula una raiz cuadrada dado un parametro bajo un cierto error
  *        especificado
  * @bug Therea are  no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */
#include <iostream>
#include <cmath>
const double kEpsilon = 1e-4; 

double ApproximateRoot(double number){
  double root = 1.0;
  double delta = 1.0;
  while ( (abs( (root * root) - number) ) > kEpsilon){
    if (delta > 0){
      while ((root * root) < number){
        root += delta;
      }
    }
   else{
     while ((root * root ) > number){
       root += delta;
     }
   }
   delta *= -0.5;
  }
  return root;
}

int main(int argc, char* argv[]){
  if (argc != 2){
    std::cerr << "Ejemplo de ejecucion: ./approximate_root 8 ";
    return 1;
  }
  double value = std::stoi(argv[1]);
  if (value <= 0){
    std::cerr << "Valor no admitido";
    return 2;
  }
  std::cout << ApproximateRoot(value) << std::endl;
  return 0;
}
  

