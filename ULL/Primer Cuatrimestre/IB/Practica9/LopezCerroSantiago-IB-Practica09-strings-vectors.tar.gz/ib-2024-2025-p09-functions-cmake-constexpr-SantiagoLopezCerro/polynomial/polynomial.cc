/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Santiago Lopez Cerro alu0101763613@ull.edu.es
  * @date Nov 17 2024
  * @brief Dado un valor y unos coeficientes evalua el polinomio correspondiente
  * @bug Therea are  no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */
#include <iostream>
#include <string>
#include <vector>

std::vector<double> StringToVector (std::string cadena){
  std::vector<double> resultado;
  std::string numero;
  numero = "";
  for (int i = 0; i < cadena.size(); i++){
    if ( cadena[i] !=  '-')
      numero.push_back(cadena[i]);
    else{ 
      if (!numero.empty()){
        resultado.push_back(std::stod(numero));
        numero.clear();
      }
    }
  }
  if(!numero.empty())
    resultado.push_back(std::stod(numero));
  return resultado;
}

double EvaluaPolinomio (double value, std::vector<double> coef){
  double result = coef.at(0);
  for (int i = 0; i < coef.size() - 1; i++){
    result = value*result + coef.at(i + 1);
  }
  return result;
}

int main(int argc, char* argv[]){
    if (argc != 3){
      std::cerr << "Ejemplo de ejecucion: ./polynomial 3 3.5-8-2 ";
    return 1;
  }
  double value = std::stoi(argv[1]);
  std::vector<double> coeficientes = StringToVector(argv[2]);
  std::cout << EvaluaPolinomio(value, coeficientes) << std::endl;
  return 0;
}

  
