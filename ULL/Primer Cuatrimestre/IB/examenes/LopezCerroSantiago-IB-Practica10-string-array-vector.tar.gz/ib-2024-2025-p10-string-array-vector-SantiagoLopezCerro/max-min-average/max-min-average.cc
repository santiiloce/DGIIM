/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Santiago Lopez Cerro alu0101763613@ull.edu.es
  * @date Nov 25 2024
  * @brief Funcion que calcula el maximo, minimo y promedio de un vector dado
  * @bug Therea are  no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */
#include <iostream>
#include <vector>

struct Datos{
  double max;
  double min;
  double average;
};

Datos DatosVector(std::vector<double> nums){
  Datos sol;
  sol.max = 0;
  sol.min = 0;
  sol.average = 0;
  for(int i = 0; i < nums.size(); i++){
    sol.average += nums.at(i);
    if (nums.at(sol.max) < nums.at(i)){
      sol.max = i;
    }
    if (nums.at(sol.min) > nums.at(i))
      sol.min = i;
  }
  sol.average /= nums.size();
  sol.max = nums.at(sol.max);
  sol.min = nums.at(sol.min);
  return sol;
}

int main( int argc, char* argv[]){
  std::vector<double> nums;
  if (argc == 1){
    std::cerr << "Ejemplo de ejecucion: ./max-min-average 23 8.0 2.5 ";
    return 1;
  }
  for (int i = 1; i < argc; i++){
    nums.push_back(std::stod(argv[i]));
  }
  Datos sol;
  sol = DatosVector(nums);
  std::cout << "Min: " << sol.min << std::endl;
  std::cout << "Max: " << sol.max << std::endl;
  std::cout << "Average: " << sol.average << std::endl;
  return 0;
}
