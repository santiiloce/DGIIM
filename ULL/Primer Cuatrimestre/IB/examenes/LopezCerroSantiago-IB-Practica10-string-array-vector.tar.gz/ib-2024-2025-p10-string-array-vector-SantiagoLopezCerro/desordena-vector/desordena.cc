/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Santiago Lopez Cerro alu0101763613@ull.edu.es
  * @date Nov 25 2024
  * @brief Funcion que dado un vector desordena sus valores
  * @bug Therea are  no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */
#include <iostream>
#include <vector>
#include <random>

void Intercambia(std::vector<double>& nums, int pos1, int pos2){
  double aux = nums.at(pos1);
  nums.at(pos1) = nums.at(pos2);
  nums.at(pos2) = aux;
}

void DesordenaVector(std::vector<double>& nums){
  std::srand(static_cast<unsigned int>(time(nullptr)));
  for(int i = 0; i < nums.size(); i++){
    int pos =  std::rand() %  (nums.size());
    Intercambia(nums, i , pos);
  }
}

int main( int argc, char* argv[]){
  std::vector<double> nums;
  if (argc == 1){
    std::cerr << "Ejemplo de ejecucion: ./desordena-vector 23 8.0 2.5 ";
    return 1;
  }
  for (int i = 1; i < argc; i++){
    nums.push_back(std::stod(argv[i]));
  } 
  DesordenaVector(nums);
  for (int i = 0; i < nums.size(); i++) {
    std::cout << "Component: " << nums.at(i) << std::endl;
  }
  return 0;

}
