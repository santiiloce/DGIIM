/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Santiago Lopez Cerro alu0101763613@ull.edu.es
  * @date Nov 25 2024
  * @brief Funcion que da la cantidad de numeros en comun de dos vectores
  * @bug Therea are  no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */
  
  #include <iostream>
  #include <vector>
   int common_elements(const std::vector<int>& X, const std::vector<int>& Y){
     int common = 0;
     for(int i = 0; i < X.size(); i++){
       for(int j = 0; j < Y.size(); j++){
	 if(X.at(i) == Y.at(j)){
            common++;
	 }
        }
     }
    return common;
  }

