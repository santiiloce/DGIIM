#include <iostream>
#include <vector>

bool igualdad(std::vector<int> nums){
  for( int i = 0; i < nums.size(); i++){
    int suma = 0;
    for (int j = 0; j < nums.size(); j++){
      if (nums.at(i) != nums.at(j)){
        suma += nums.at(j);
        if( j == nums.size() - 1){
          if (suma == nums.at(i))
             return true;
          }
        }
    }
  }
  return false;
  }
  
  int main(){
    std::vector<int> nums;
    int size;
    while(std::cin >> size){
      for(int i=0; i < size; i++){
        int aux;
        std::cin >> aux;
        nums.push_back(aux);
      }
      if(igualdad(nums)){
        std::cout << "YES" << std::endl;
      }
      else
        std::cout << "NO" << std::endl;
     }
   return 0;   
 }
