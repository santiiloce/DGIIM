/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Santiago López Cerro alu0101763613@ull.edu.es
 * @date Nov 13 2024
 * @brief Funcion que devuelve al psoicion del elamento maxima de un vector 
 * The program takes directly the input and prints the output
 */

#include <iostream>
#include <vector>

int position_maximum(const std::vector<double>& v, int m){
  int max = 0;
  for(int i = 0; i <= m; i++){
    if(v.at(max) < v.at(i) || (v.at(max) == v.at(i) && i < max)){
      max = i;
    }
  }
  return max ;
}


