#include "leap.h"

namespace leap {
bool is_leap_year(const int year){
    bool leap = false;
  if (year % 400 == 0){
    leap = true;
  }
  else if (year % 100 == 0){
    leap = false;
  }
  else if (year % 4 == 0){
    leap = true;
  }
  return leap;
 }
}  // namespace leap


