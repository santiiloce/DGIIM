/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Santiago Lopez Cerro alu0101763613@ull.edu.es
  * @date Nov 25 2024
  * @brief Funcion que inicializa un vector de valores aleatorios comprendidos
  * en un intervalo y de tamanio size
  * @bug Therea are  no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */
#include <iostream>
#include <vector>
#include <random>

std::vector<double> GenerateVector(const int size, const double lower, const
double upper){
  std::vector<double> result(size);
  std::srand(static_cast<unsigned int>(time(nullptr)));
  for (int i = 0; i < size; i++){
    result.at(i) = (lower + static_cast<double>(std::rand()) / (static_cast<double>(RAND_MAX) / (upper - lower)));
  }
  return result;
}
 
int main(int argc, char* argv[]){
   if (argc != 4){
    std::cerr << "Ejemplo de ejecucion: ./generate-vector 30 5.0 10.0 ";
    return 1;
  }
  int size = std::stoi(argv[1]);
  double lower = std::stod(argv[2]);
  double upper = std::stod(argv[3]);
  std::vector my_vector = GenerateVector(size, lower, upper); 
  for (const auto& value: my_vector) {
    std::cout << "Component: " << value << std::endl;
  }
  return 0;
}  
