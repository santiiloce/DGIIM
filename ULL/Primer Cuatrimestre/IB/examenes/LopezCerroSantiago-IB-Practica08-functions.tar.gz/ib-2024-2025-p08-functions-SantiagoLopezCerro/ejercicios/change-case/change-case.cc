/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Santiago Lopez Cerro alu0101763613@ull.edu.es
  * @date Nov 10 2022
  * @brief Cambias las letras en minusculas a mayusculas y viceversa
  * @bug Therea are  no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */
#include <iostream>
#include <string>

/**
 * Funcion que transforma una letra minuscula en mayuscula y viceversa
 *
 * @param valores letra
 * @return letra en el formato opuesto al de inicio
 */
char TransformaLetra (char letra){
  if ('a' <= letra && letra <= 'z')
    letra -= ('a' - 'A');
  else if ('A' <= letra && letra <= 'Z')
    letra += ('a' - 'A');
  return letra;
}
 
int main (int argc, char* argv[]){
  if (argc != 2){
    std::cerr << "Valor esperado --> una cadena tipo string)";
    return 1;
  }
  char aux;
  std::string palabra = argv[1];
  for (int i = 0; i < palabra.size(); i++){
    aux = TransformaLetra(palabra[i]);
    palabra[i] = aux;
  }
  std::cout << palabra << std::endl;
  return 0;
}
  

