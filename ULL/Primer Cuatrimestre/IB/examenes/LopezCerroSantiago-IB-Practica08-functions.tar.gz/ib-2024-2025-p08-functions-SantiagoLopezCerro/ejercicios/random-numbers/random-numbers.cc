/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Santiago Lopez Cerro alu0101763613@ull.edu.es
  * @date Nov 10 2024
  * @brief Programa que genera un numero real dado un intervalo
  * @bug Therea are  no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */
#include <iostream>
#include <cstdlib>
#include <ctime>

/**
 * Funcion que genera un numero real aleatorio de tres decimales
 *
 * @param valores max, min representando los extremos del intervalo
 * @return numero aleatorio real
 */
double CreateRandom(int min, int max){
  srand(static_cast<unsigned int>(time(0)));
  double random = rand() % (max - min + 1) + min;
  double decimal = (rand() % (999 +  1)) / 1000.0;  // Genero de forma aleatoria la parte
  random += decimal;                                // decimal
  return random;
}

int main(int argc, char* argv[]){
  if (argc != 3){
    std::cerr << "Valores esperados num1 y num2, extremos del intervalo)";
    return 1;
  }
  int min = atoi(argv[1]);
  int max = atoi(argv[2]);
  double random = CreateRandom(min, max);
  std::cout << random << std::endl;
  return 0;
}



