/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Santiago Lopez Cerro alu0101763613@ull.edu.es
  * @date Nov 10 2024
  * @brief El programa que ejecuta una funcion matematica de tres variables
  * @bug Therea are  no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */
#include <iostream>
#include <cmath>

/**
 * Funcion matemática
 *
 * @param valores t, x, y
 * @return resultado de la ejecucion de la funcion
 */
double funcion_matematica( double x, double y, double t){
  return sqrt(2*t - 4) / (x * x - y * y);
}

int main(int argc, char* argv[]){
  if (argc != 4){
    std::cerr << "Valores esperados x y t)";
    return 1;
  }
  double x, y, t, resultado;
  x = atoi(argv[1]);
  y = atoi(argv[2]);
  t = atoi(argv[3]);
  resultado = funcion_matematica(x,y,t);
  std::cout << resultado << std::endl;
  return 0;
}
