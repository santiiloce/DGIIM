/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Santiago Lopez Cerro alu0101763613@ull.edu.es
  * @date Nov 10 2024
  * @brief El programa determina la igualdad de dos numeros con cierta exactitud
  * @bug Therea are  no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */
#include <iostream>
#include <cmath>

/**
 * Funcion de comparación de igualdad de de dos valores
 *
 * @param valores a comparar, double number1 y double number2
 * @return bool indicado la veracidad de su igualdad
 */
bool AreEqual(const double number1, const double number2, const double epsilon
= 1e-7){
  double a = number1;
  double b = number2;
  return fabs(a - b) < (epsilon);
}

int main(int argc, char* argv[]){
  if (argc != 4){
    std::cerr << "./<nombre_ejectable> num1 num2 epsilon";
    return 1;
  }
  double num1, num2, epsilon;
  num1 = atoi(argv[1]);
  num2 = atoi(argv[2]);
  epsilon = atoi(argv[3]);
  std::cout << AreEqual(num1, num2, epsilon) << std::endl;
  return 0;
}
  

