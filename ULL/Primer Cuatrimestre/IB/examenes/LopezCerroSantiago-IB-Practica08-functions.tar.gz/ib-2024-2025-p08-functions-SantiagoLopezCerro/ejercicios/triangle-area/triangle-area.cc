/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @author Santiago Lopez Cerro alu0101763613@ull.edu.es
  * @date Nov 10 2024
  * @brief Calcula el area de un triangulo con la formula de Heron
  * @bug Therea are  no known bugs
  * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
  */
#include <iostream>
#include <cmath>

/**
 * Determina si los lados de un tringulo cumplen la desigualdad triangular
 *
 * @param a,b,c lados de un triangulo
 * @return bool valid indicando si es valido
 */
bool IsAValidTriangle(double a, double b, double c){
  bool valid = true;
  if (a >= b + c)
    valid = false;
  else if (b >= a + c)
    valid = false;
  else if (c >= a + b)
    valid = false;
  return valid;
}

/**
 * Calcula area
 *
 * @param a, b, c lados del triangulo
 * @return area del triangulo
 */
double Area(double a, double b, double c){
  if ( !IsAValidTriangle(a, b ,c)) // Validacion adicional
    return -1;
  double sp = (a + b + c) / 2; // Calculo el semiperimetro
  return sqrt( sp * ( sp - a ) * ( sp - b ) * ( sp - c ));
}  

int main ( int argc, char* argv[]){
  if (argc != 4){ // Valido numero de parametros
    std::cerr << "./<nombre_ejecutable> lado1 lado2 lado3";
    return 1;
  }
  double lado1, lado2, lado3;
  lado1 = atof(argv[1]);
  lado2 = atof(argv[2]);
  lado3 = atof(argv[3]);
  if (!IsAValidTriangle(lado1, lado2 ,lado3)){ 
    std::cout << "Not a valid Triangle" << std::endl;
    return 1;
  }
  std::cout << Area(lado1, lado2, lado3) << std::endl;
  return 0;
}


