/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Santiago López Cerro
 * @date Nov 11 2024
 * @brief Funcion funcion que cambia el valor de los parametros
 * The program takes directly the input and prints the output
 */

void swap2(int& a, int& b){
  int aux = a;
  a = b;
  b = aux;
}
