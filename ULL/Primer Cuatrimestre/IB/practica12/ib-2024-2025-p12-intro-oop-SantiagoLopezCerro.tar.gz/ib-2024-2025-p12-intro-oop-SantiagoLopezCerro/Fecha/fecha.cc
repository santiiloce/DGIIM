/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Santiago López Cerro alu0101763613@ull.edu.es
 * @brief Programa que contiene la clase fecha 
 * @see https://code.visualstudio.com/docs/cpp/config-linux
 */
#include <iostream>
#include <string>
#include <fstream>

class Fecha{
private:
    int day;
    int month;
    int year;
public:
    /**
     * @brief Construct a default Fecha object
     * 
     */
    Fecha(){
      day = 0;
      month = 0;
      year = 0;
    }

    /**
     * @brief Pasa la fecha a un tipo string
     * 
     * @return std::string 
     */
    std::string FechaToString(){
        std::string fecha;
        fecha = std::to_string(day) + "/" + std::to_string(month) + "/" + std::to_string(year);
        return fecha;
    }

    /**
     * @brief Imprime por pantalla la fecha 
     * 
     */
    void Print(){
        std::cout << FechaToString() << std::endl;
    }

  /**
   * @brief Comprueba si es un anio bisiesto
   * 
   * @param year 
   * @return true 
   * @return false 
   */
  bool is_leap_year(int year = -1){
    if(year < 0){
      year = this->year;
    }
    bool bisiesto = false;
    if (year % 4 == 0)
      bisiesto = true;
      
    if (year % 100 == 0 && year % 400 != 0) // Considero excepcion
      bisiesto = false;
    return bisiesto;
  }

  /**
   * @brief Verifica si la fecha es válida
   * 
   * @param d dia
   * @param m mes
   * @param y anio
   * @return true es valida
   * @return false no es valida
   */
  bool is_valid_date(int d, int m, int y){
    bool valid = true;
    
    if (m < 1 || m > 12)
      return false;
      
    if (m > 7) // Aniado uno para que se siga cumpliendo la alternancia
      m++; 	 // Habiendo comprobado anteriormente que es un mes valido
    if (m % 2 != 0){
      if (d < 1 || d > 31)
        return false;
    }
    else{ 
      if (m == 2){
        if (is_leap_year(y)){
          if (d < 1 || d > 29)
            return false;
        }
        else{ 
          if (d < 1 || d > 28)
            return false;
        }
      }
      else{ 
        if (d < 1 || d > 30)
            return false;
      }
    }
            
    return true;
          
  }

  /**
   * @brief Cambia la fecha actual por una recibida por parámetros
   * 
   * @param day nuevo dia
   * @param month nuevo mes
   * @param year nuevo anio
   */
  void CambiaFecha(int day, int month, int year){
    if(!is_valid_date(day,month, year)){
      std::cerr << "Fecha inválida ";
      return;
    }
    else{
      this->day = day;
      this->month = month;
      this->year = year;
    }
  }

  /**
   * pre: la fecha debe estar en formato dd/mm/yyyyy
   * @brief Obtiene de un archivo una fecha
   * 
   * @param file 
   */
  void ReadFile(std::string file){

      std::ifstream archivo(file);
      if (archivo.is_open()){
          std::cerr<<"Error al abrir archivo";
          return;
      }
      std::string date;
      archivo >> date;
      std::string aux_year = "";
      std::string aux_month = "";
      std::string aux_day = "";
      int i;
      for(i = 0; i < date.size() && date.at(i) != '/'; i++){
        aux_day += date.at(i);
      }
      int j;
      for(j = i + 1; j < date.size() && date.at(j) != '/'; j++ ){
        aux_month += date.at(j);
      }
      int k;
      for(k = j + 1; k < date.size(); k++){
        aux_year += date.at(k);
      }

      CambiaFecha(std::stoi(aux_day), std::stoi(aux_month), std::stoi(aux_year));
  }

  /**
   * @brief Utiliza un string para inicializar la fecha
   * 
   * @param date archivo de donde leer la fecha
   */
  void ReadDate(std::string date){
      std::string aux_year = "";
      std::string aux_month = "";
      std::string aux_day = "";
      int i;
      for(i = 0; i < date.size() && date.at(i) != '/'; i++){
        aux_day += date.at(i);
      }
      int j;
      for(j = i + 1; j < date.size() && date.at(j) != '/'; j++ ){
        aux_month += date.at(j);
      }
      int k;
      for(k = j + 1; k < date.size(); k++){
        aux_year += date.at(k);
      }

      CambiaFecha(std::stoi(aux_day), std::stoi(aux_month), std::stoi(aux_year));
  }

  /**
   * @brief Escribe la fecha en un archivo dado
   * 
   * @param file archivo donde escribir
   */
  void WriteFile(std::string file){
    std::ofstream archivo(file);
      if (archivo.is_open()){
          std::cerr<<"Error al abrir archivo ";
          return;
      }
    archivo << this->FechaToString() << std::endl;
  }

  /**
   * @brief Construct a new Fecha object
   * 
   * @param day 
   * @param month 
   * @param year 
   */
  Fecha(int day, int month, int year){
      if(!is_valid_date(day, month, year)){
          std::cerr << "Is not a valid date "  <<std::endl;
      }
      else{
          this->day = day;
          this->month = month;
          this->year = year;
      }
  }
};

int main(int argc, char* argv[]){
  if(argc != 2){
    std::cerr << "./fechas date ";
    return 1;
  }

  Fecha fecha;
  fecha.ReadDate(argv[1]);
  fecha.Print();
  return 0;
}