/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Santiago López Cerro alu0101763613@ull.edu.es
 * @brief Funcion que contiene la clase Circulo
 * @see https://code.visualstudio.com/docs/cpp/config-linux
 */
#include <iostream>
#include <string>
#include <cmath>

const double kPi = 3.14159265359;

class Point2D{
private:
    double x;
    double y;
public:
    Point2D(){}
    
    /**
     * @brief Construct a new Point 2 D object
     * 
     * @param pos_x 
     * @param pos_y 
     */
    Point2D(double pos_x, double pos_y){
        x = pos_x;
        y = pos_y;
    }
    /**
     * @brief Muestra upor pantalla las coordenadas del punto
     * 
     * @return std::string 
     */
    std::string Show(){
        std::cout << "(" << x << ";" << y << ")" << std::endl;
    }

    /**
     * @brief Devuelve la coordenada x
     * 
     * @return double 
     */
    double GetX(){
        return x;
    }

    /**
     * @brief Devuelve la coordenada y
     * 
     * @return double coordenada y
     */
    double GetY(){
        return y;
    }
    /**
     * @brief Cambias las coordenas del punto
     * 
     * @param new_x nueva coordenada x
     * @param new_y nueva coordenada y
     */
    void Move(double new_x, double new_y){
        this->x = new_x;
        this->y = new_y;
    }
    
    /**
     * @brief Calcula la distancia entre dos puntos de la clase Point2D
     * 
     * @param point de la clase Point2D
     * @return double distancia
     */
    double Distance(Point2D point){
        double aux1 = pow((x - point.GetX()),2);
        double aux2 = pow(y - point.GetY(),2);
        return sqrt(aux1 + aux2);
    }
    
    /**
     * @brief Calcula el punto medio del punto actual y otro dado
     * 
     * @param point punto de referencia 
     * @return Point2D 
     */
    Point2D Middle(Point2D point){
        double pos_x = (x + point.GetX()) / 2;
        double pos_y = (y + point.GetY()) / 2;
        return Point2D(pos_x, pos_y);
    }
};



class Circulo{
private:
    Point2D centro;
    double radio;
    enum class Color {
        Red,
        Green,
        Blue,
        Yellow,
        Black,
        White
    };
    Color color;
public:
    /**
     * @brief Construct a new default Circulo object
     * 
     */
    Circulo(){}

    /**
     * @brief Construct a new Circulo object
     * 
     * @param point 
     * @param radio 
     * @param color 
     */
    Circulo(Point2D point, double radio, Color color){
        this->centro = point;
        this->radio = radio;
        this->color = color;
    }

    /**
     * @brief Calcula el area
     * 
     * @return double area
     */
    double Area(){
        return kPi * radio * radio;
    }

    /**
     * @brief Calcula el perimetro
     * 
     * @return double perimetro
     */
    double Perimetro(){
        return 2 * kPi * radio;
    }

    /**
     * @brief Get the Color Name object
     * 
     * @return std::string 
     */
    std::string getColorName() const {
        switch (color) {
            case Color::Red: return "Red";
            case Color::Green: return "Green";
            case Color::Blue: return "Blue";
            case Color::Yellow: return "Yellow";
            case Color::Black: return "Black";
            case Color::White: return "White";
            default: return "Unknown";
        }
    }

    /**
     * @brief Imprime toda la información relacioanda al circulo
     * 
     * @return double 
     */
    void Print(){
        std::cout << "Area: " << this->Area() << std::endl;
        std::cout << "Perimetro: " << this->Perimetro() << std::endl;
        std::cout << "Centro: " << centro.Show();
        std::cout << "Radio: " << radio << std::endl;
        std::cout << "Color " << getColorName() << std::endl;
    }

    /**
     * @brief Determina si dado un punto este está contenido en el circulo
     * 
     * @param point 
     * @return true 
     * @return false 
     */
    bool EsInterior(Point2D point){
        if(this->centro.Distance(point) <= radio)
          return true;
        else
          return false;
    }


};
