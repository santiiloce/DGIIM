/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Santiago López Cerro alu0101763613@ull.edu.es
 * @brief Programa con la clase complejo y sus respectivas operaciones
 * @see https://code.visualstudio.com/docs/cpp/config-linux
 */

#include "Complex.h"
#include <cmath>
#include <stdexcept> 
#include <iostream>
#include <string>


    Complex::Complex() : realPart(0.0), imagPart(0.0) {}

    Complex::Complex(double real, double imaginary) : realPart(real), imagPart(imaginary) {}

    double Complex::real() const { return realPart; }
    double Complex::imag() const { return imagPart; }

    Complex Complex::operator+(const Complex& num) const {
        return Complex(realPart + num.realPart, imagPart + num.imagPart);
    }

    Complex Complex::operator+(double scalar) const {
        return Complex(realPart + scalar, imagPart);
    }

    Complex operator+(double scalar, const Complex& c) {
        return c + scalar; 
    }

    Complex Complex::operator-(const Complex& num) const {
        return Complex(realPart - num.realPart, imagPart - num.imagPart);
    }

    Complex Complex::operator-(double scalar) const {
        return Complex(realPart - scalar, imagPart);
    }

    Complex operator-(double scalar, const Complex& c) {
        return Complex(scalar - c.realPart, -c.imagPart);
    }

    Complex Complex::operator*(const Complex& num) const {
        double real = realPart * num.realPart - imagPart * num.imagPart;
        double imag = realPart * num.imagPart + imagPart * num.realPart;
        return Complex(real, imag);
    }

    Complex Complex::operator*(double scalar) const {
        return Complex(realPart * scalar, imagPart * scalar);
    }

    Complex operator*(double scalar, const Complex& c) {
        return c * scalar;
    }

    Complex Complex::operator/(const Complex& num) const {
        double denom = num.realPart * num.realPart + num.imagPart * num.imagPart;
        if (denom == 0) {
            throw std::runtime_error("Division by zero");
        }
        double real = (realPart * num.realPart + imagPart * num.imagPart) / denom;
        double imag = (imagPart * num.realPart - realPart * num.imagPart) / denom;
        return Complex(real, imag);
    }

    Complex Complex::operator/(double scalar) const {
        if (scalar == 0) {
            throw std::runtime_error("Division by zero");
        }
        return Complex(realPart / scalar, imagPart / scalar);
    }

    Complex operator/(double scalar, const Complex& c) {
        double denom = c.realPart * c.realPart + c.imagPart * c.imagPart;
        if (denom == 0) {
            throw std::runtime_error("Division by zero");
        }
        double real = (scalar * c.realPart) / denom;
        double imag = (-scalar * c.imagPart) / denom;
        return Complex(real, imag);
    }

    Complex Complex::conj() const {
        return Complex(realPart, -imagPart);
    }

    double Complex::abs() const {
        return std::sqrt(realPart * realPart + imagPart * imagPart);
    }

    Complex Complex::exp() const {
        double expReal = std::exp(realPart);
        return Complex(expReal * std::cos(imagPart), expReal * std::sin(imagPart));
    }

    std::ostream& operator<<(std::ostream& os, const Complex num){
        std::string salida = "";
        salida += std::to_string(num.real());
        if(num.imag() < 0){
            salida += " - " + std::to_string(-num.imag());
        }
        else{
            salida += " + " + std::to_string(-num.imag());
        }
        salida += "*i";
        os << salida << std::endl;
    }

    int main(){
        Complex complejo1{4, 5}, complejo2{7, -8};
        Complex resultado;
        resultado = complejo1 + complejo2;
        std::cout << resultado;
        resultado = complejo1 - complejo2;
        std::cout << resultado;
        return 0;
    }

