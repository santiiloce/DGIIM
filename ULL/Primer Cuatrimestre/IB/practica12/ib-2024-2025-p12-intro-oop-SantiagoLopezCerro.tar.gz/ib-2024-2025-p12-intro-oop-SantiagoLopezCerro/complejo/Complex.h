#ifndef COMPLEX_NUMBERS_H
#define COMPLEX_NUMBERS_H

#include <cmath>
#include <stdexcept> 
#include <iostream>


class Complex {
    private:
        double realPart;
        double imagPart;

    public:
        Complex();
        Complex(double real, double imaginary);

        double real() const;
        double imag() const;

        Complex operator+(const Complex& num) const;
        Complex operator+(double scalar) const;
        friend Complex operator+(double scalar, const Complex& c);

        Complex operator-(const Complex& num) const;
        Complex operator-(double scalar) const;
        friend Complex operator-(double scalar, const Complex& c);

        Complex operator*(const Complex& num) const;
        Complex operator*(double scalar) const;
        friend Complex operator*(double scalar, const Complex& c);

        Complex operator/(const Complex& num) const;
        Complex operator/(double scalar) const;
        friend Complex operator/(double scalar, const Complex& c);

        void operator<<(const Complex);

        Complex conj() const;
        double abs() const;
        Complex exp() const;
};


#endif
