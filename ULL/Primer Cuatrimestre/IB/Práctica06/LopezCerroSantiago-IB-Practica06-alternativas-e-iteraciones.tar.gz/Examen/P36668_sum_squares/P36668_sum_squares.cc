/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Santiago López Cerro
 * @date Oct 16 2024
 * @brief Suma de cuadrados
 *        The program takes directly the input and prints the output
 */

#include <iostream>

int main(){
  int num, suma;
  suma = 0;
  std::cin >> num;
  for(int i  = 1; i <= num; i++){
    suma +=  i*i;
  }
  std::cout << suma << std::endl;
  return 0;
}
