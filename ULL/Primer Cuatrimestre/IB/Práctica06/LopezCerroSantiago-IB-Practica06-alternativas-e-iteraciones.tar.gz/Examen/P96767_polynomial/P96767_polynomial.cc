/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Santiago López Cerro
 * @date Oct 28 2024
 * @brief Programa diseñado evaluar un polinomio
 *        The program takes directly the input and prints the output
 */
#include <iostream>
#include <iomanip>
#include <cmath>

int main(){
  int valor, resultado, size;
  resultado = 0;
  std::cin >> valor;
  size = round(abs(valor));
  int datos[size+1];

    std::cin >> datos[i];
 
  for(int i = 0; i< size; i++)
    resultado += (datos[i] * pow(valor,i));

  std::cout << std::fixed << std::setprecision(4);
  std::cout << resultado << std::endl;
  return 0;
}
