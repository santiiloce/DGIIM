/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Santiago López Cerro
 * @date Oct 28 2024
 * @brief Programa que imprime un numero dado en binario al reves
 *        The program takes directly the input and prints the output
 */

#include <iostream>
#include <queue>
using namespace std;
int main(){
  int num;
  cin>>num;
  queue<int> binario;
  while(num != 0 || num != 1){
    int aux=num%2;
    binario.push(aux);
    num/2;
  }
  binario.push(num%2);
  while(!binario.empty()){
    cout << binario.front();
    binario.pop();
  }
  cout  << endl;
  return 0;
}
